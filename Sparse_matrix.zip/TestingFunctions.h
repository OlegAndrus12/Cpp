#include "SparseMatrixSpec.h"
#include <iostream>
template<typename T>
void DisplayMatrix(const SparseMatrix<T>& matrix);
SparseMatrix <int> InitInt();
SparseMatrix <char> InitChar();
SparseMatrix <double> InitDouble();
SparseMatrix <std::complex<double> > InitComplex ();
SparseMatrix <std::string> InitString();
void TestConstruct();
void TestCopyConstruct();
void TestHeightWidth();
void TestSetSize();
void TestGetAndSetEl();
void TestSingular();
void TestTranspose();
void TestAssignOperator ();
void TestOperatorAdd();
void TestOperatorSub();
void TestMulMatrix();
void TestAddAssign();
void TestSubAssign();
void TestMulNum();
void TestMulNumAssign();
void TestEqual();
void TestNotEqual();
