#ifndef _SPARSEMATRIX_
#define _SPARSEMATRIX_
#include <map>
#include <exception>

template <typename T>
struct SparseMatrixTraits
{
	typedef const T& const_reference;
	typedef T value_type;
	static value_type DefaultValue() { return 0; }
	static value_type oper_add (const_reference x,const_reference y ) 
	{
		return x+y;
	}
	static value_type oper_sub (const_reference x,const_reference y) 
	{
		return x-y;
	}
	static value_type oper_mul (const_reference x,const_reference y) 
	{
		return x*y;
	}
	static value_type oper_mul_double (const_reference x, double y) 
	{
		return x*y;
	}
};

static bool operator< (const std::pair<unsigned int,unsigned int>& x, const std::pair<unsigned int,unsigned int>& y) 
{
	if (x.first!=y.first)
	{
		return x.first<y.first;
	}
	else
	{
		return x.second<y.second;
	}
}

class SparseMatrixExc : public std::exception {};
class OutOfRange : public SparseMatrixExc 
{
public:
	const char *what() const throw()
	{
		return "Out of range";
	}
};
class NotCompatible : public SparseMatrixExc 
{
public:
	const char *what() const throw()
	{
		return "Not compatible matrices";
	}	
};

//--------------------------------------SPARSE MATRIX TEMPLATE CLASS--------------------------------
template <typename T, typename C = std::map<std::pair<unsigned int,unsigned int>, T> >
class SparseMatrix
{
public:
	typedef const T& const_reference;
	typedef T value_type;
	typedef C container;
	typedef std::pair<unsigned int,unsigned int> place_type;//first is a row, second is a column
	SparseMatrix()
	{
		height=0;
		width=0;
	}
	SparseMatrix(unsigned int _height, unsigned int _width)
	{
		height=_height;
		width=_width;
	}
	SparseMatrix (const SparseMatrix& _matrix):data(_matrix.data),height(_matrix.height),width(_matrix.width) {}
	~SparseMatrix() throw() {}
	unsigned int GetHeight() const {return height;}
	unsigned int GetWidth() const {return width;}
	void SetSize(unsigned int _height, unsigned int _width)
	{
		if (height <= _height && width <= _width) 
		{
			height=_height;
			width=_width;
		}
		if (height > _height || width > _width) 
		{
			typename container::iterator i=data.begin();
			while (i!=data.end())
			{
				if ( i->first.first > _height || i->first.second > _width ) 
				{
					data.erase(i++);
				}
				else
				{
					i++;
				}
			}
			height=_height;
			width=_width;
		}
	}
	value_type At(unsigned int row, unsigned int col) const
	{
		if (row>height || col>width || row==0 || col==0)
			throw OutOfRange();
		typename container::const_iterator i=data.find(std::make_pair(row,col));
		if (i!=data.end())
		{
			return i->second;	
		}
		else
		{
			value_type ret = SparseMatrixTraits<T>::DefaultValue();
			return ret;
		}
	}
	void SetAt(unsigned int row, unsigned int col, const_reference value)
	{
		if (row>height || col>width || row==0 || col==0)
			throw OutOfRange();
		place_type myplace = std::make_pair(row,col);
		typename container::iterator i=data.find(myplace);
		if (i==data.end())
		{
			if (value==SparseMatrixTraits<T>::DefaultValue() )
			{
				return;
			}
			else
			{
				data.insert(std::make_pair(myplace, value));
			}
		}
		else
		{
			if (value==SparseMatrixTraits<T>::DefaultValue() )
			{
				data.erase(i);
			}
			else
			{
				data[myplace] = value;
			}
		}
	}
	bool IsSingular() const
	{
		bool* prows=new bool[height+1];
		bool* pcols=new bool[width+1];
		unsigned int j;
		for (j=0;j<=height;j++)
			prows[j]=false;
		for (j=0;j<=width;j++)
			pcols[j]=false;
		for (typename container::const_iterator i=data.begin();i!=data.end();++i)
		{
			prows[i->first.first]=true;
			pcols[i->first.second]=true;
		}
		bool answer=false;
		for (j=1;j<=height;j++)
			if (!prows[j])
			{
				answer = true;
				break;
			}
		if (!answer) 
			for (j=1;j<=width;j++)
				if (!pcols[j])
				{
					answer = true;
					break;
				}
		delete [] prows;
		delete [] pcols;
		return answer;
	}
	SparseMatrix Transpose() const
	{
		SparseMatrix ret (width,height);
		std::pair<place_type,value_type> newinsert;
		for (typename container::const_iterator i=data.begin();i!=data.end();++i)
		{
			newinsert.first.first=i->first.second;
			newinsert.first.second=i->first.first;
			newinsert.second=i->second;
			ret.data.insert(newinsert);
		}
		return ret;
	}
	SparseMatrix& operator = (const SparseMatrix& _matrix)
	{
		if (this == &_matrix) return *this;
		data=_matrix.data;
		height=_matrix.height;
		width=_matrix.width;
		return *this;
	}
	SparseMatrix operator + (const SparseMatrix& _matrix) const
	{
		if (height!=_matrix.height || width!=_matrix.width)
			throw NotCompatible();
		SparseMatrix temp (*this);
		temp+=_matrix;
		return temp;
	}
	SparseMatrix operator - (const SparseMatrix& _matrix) const
	{
		if (height!=_matrix.height || width!=_matrix.width)
			throw NotCompatible();
		SparseMatrix temp (*this);
		temp-=_matrix;
		return temp;
	}
	SparseMatrix operator * (const SparseMatrix& _matrix) const
	{
		if (width!=_matrix.height)
			throw NotCompatible();
		SparseMatrix temp(height,_matrix.width);
		typename container::const_iterator Aiter = data.begin();
		typename container::const_iterator Biter;
		typename container::iterator Citer;
		while(Aiter!=data.end())
		{
			Biter=_matrix.data.begin();
			while(Biter!=_matrix.data.end())
			{
				if (Aiter->first.second==Biter->first.first)
				{
					typename container::value_type mypair (std::make_pair(Aiter->first.first,Biter->first.second), SparseMatrixTraits<T>::oper_mul(Aiter->second, Biter->second));
					Citer = temp.data.find(mypair.first);
					if (Citer==temp.data.end())
					{
						temp.data.insert(mypair);		
					}
					else
					{
						Citer->second = SparseMatrixTraits<T>::oper_add(Citer->second, mypair.second);
					}
				}
				if (Biter->first.first > Aiter->first.second) break;//a tiny optimization
				Biter++;
			}
			Aiter++;
		}
		return temp;
	}

	SparseMatrix& operator += (const SparseMatrix& _matrix)
	{
		if (height!=_matrix.height || width!=_matrix.width)
			throw NotCompatible();
		for (typename container::const_iterator i=_matrix.data.begin();i!=_matrix.data.end();++i)
		{
			typename container::iterator j=data.find(i->first);
			if (j==data.end())
			{
				data.insert(*i);
			}
			else
			{
				j->second=SparseMatrixTraits<T>::oper_add(j->second,i->second);
			}
		}
		return *this;
	}
	SparseMatrix& operator -= (const SparseMatrix& _matrix)
	{
		if (height!=_matrix.height || width!=_matrix.width)
			throw NotCompatible();
		for (typename container::const_iterator i=_matrix.data.begin();i!=_matrix.data.end();++i)
		{
			typename container::iterator j=data.find(i->first);
			if (j==data.end())
			{
				std::pair<typename container::iterator, bool> tmp = data.insert(*i);
				if (tmp.second) (tmp.first)->second = SparseMatrixTraits<T>::oper_sub(0,(tmp.first)->second);
			}
			else
			{
				j->second=SparseMatrixTraits<T>::oper_sub(j->second,i->second);
			}
		}
		return *this;
	}

	SparseMatrix operator * (double num) const
	{
		SparseMatrix temp(height,width);
		if (num==0) 
			return temp;
		temp.data = data;
		temp *= num;
		return temp;
	}

	SparseMatrix& operator *= (double num)
	{
		if (num==0) 
		{
			data.clear();
			return *this;
		}
		for (typename container::iterator i=data.begin();i!=data.end();++i)
		{
			i->second = SparseMatrixTraits<T>::oper_mul_double(i->second, num);
		}
		return *this;
	}
	bool operator == (const SparseMatrix& _matrix) const
	{
		if (height!=_matrix.height) return false;
		if (width!=_matrix.width) return false;
		return data==_matrix.data;
	}
	bool operator != (const SparseMatrix& _matrix) const
	{
		return !((*this)==_matrix);
	}
private:
    container data;
    unsigned int height, width;
};


#endif /* _SPARSEMATRIX_ */
//HAPPY END
