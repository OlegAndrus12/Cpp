#include "TestingFunctions.h"
#include <cstddef>

int main ()
{
	std::cout<<"Testing constructors and DisplayMatrix:\n";
	TestConstruct();
	std::cout<<"Test copy constructors:\n";
	TestCopyConstruct();
	std::cout<<"Test GetWidth and GetHeight:\n";
	TestHeightWidth();
	std::cout<<"Test SetSize:\n";
	TestSetSize();
	std::cout<<"Test At and SetAt:\n";
	TestGetAndSetEl();
	std::cout<<"Test IsSingular:\n";
	TestSingular();
	std::cout<<"Test Transpose:\n";
	TestTranspose();
	std::cout<<"Test operator= :\n";
	TestAssignOperator ();
	std::cout<<"Test operator+ :\n";
	TestOperatorAdd();
	std::cout<<"Test operator- :\n";
	TestOperatorSub();
	std::cout<<"Test operator* (matrix) :\n";
	TestMulMatrix();
	std::cout<<"Test operator+= :\n";
	TestAddAssign();
	std::cout<<"Test operator-= :\n";
	TestSubAssign();
	std::cout<<"Test operator* (number) :\n";
	TestMulNum();
	std::cout<<"Test operator*= (number) :\n";
	TestMulNumAssign();
	std::cout<<"Test operator== :\n";
	TestEqual();
	std::cout<<"Test operator!= :\n";
	TestNotEqual();
	return EXIT_SUCCESS;
}
