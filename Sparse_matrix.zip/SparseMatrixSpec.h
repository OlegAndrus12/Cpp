#ifndef _SPARSEMATRIXSPEC_
#define _SPARSEMATRIXSPEC_

#include "SparseMatrix.h"
#include <complex>
#include <string>

template <>
struct SparseMatrixTraits<std::string>
{
	typedef const std::string& const_reference;
	typedef std::string value_type;
	static value_type DefaultValue() { return ""; }
	static value_type oper_add (const_reference x, const_reference y) 
	{
		std::string ret;
		ret+=x;
		ret+=y;
		return ret;
	}	
};


#endif /*_SPARSEMATRIXSPEC_*/
