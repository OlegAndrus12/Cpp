#include "TestingFunctions.h"
template <>
std::complex<double> SparseMatrixTraits<std::complex<double> >::DefaultValue() 
{
    std::complex<double> ret(0,0);
    return  ret;
}
template<typename T>
void DisplayMatrix(const SparseMatrix<T>& matrix) 
{
	for (unsigned int i=1;i<=matrix.GetHeight();i++)
	{
		for (unsigned int j=1;j<=matrix.GetWidth();j++)
			std::cout<<matrix.At(i,j)<<'\t';
		std::cout<<std::endl;
	}
}
SparseMatrix <int> InitInt()
{
	SparseMatrix <int> ret (5,4);
	ret.SetAt(1,1,1);
	ret.SetAt(2,2,4);
	ret.SetAt(3,1,-11);
	ret.SetAt(5,2,-8);
	ret.SetAt(3,4,54);
	ret.SetAt(4,1,12);
	return ret;
}
SparseMatrix <char> InitChar()
{
	SparseMatrix <char> ret (5,4);
	ret.SetAt(1,1,'a');
	ret.SetAt(2,2,'4');
	ret.SetAt(3,1,'n');
	ret.SetAt(5,2,'$');
	ret.SetAt(3,4,'u');
	ret.SetAt(4,1,'[');
	return ret;
}
SparseMatrix <double> InitDouble()
{
	SparseMatrix <double> ret (3,4);
	ret.SetAt(1,1,1.02);
	ret.SetAt(2,2,4.7);
	ret.SetAt(3,1,-11.9);
	ret.SetAt(3,2,-8.45);
	ret.SetAt(3,4,54.12);
	ret.SetAt(2,1,12.36);
	return ret;
}
SparseMatrix <std::complex<double> > InitComplex ()
{
	SparseMatrix <std::complex<double> > ret (5,6);
	ret.SetAt(1,1,std::complex<double> (7.8,4) );
	ret.SetAt(2,2,std::complex<double> (5.2,0) );
	ret.SetAt(3,1,std::complex<double> (0,12) );
	ret.SetAt(5,2,std::complex<double> (0,8) );
	ret.SetAt(3,4,std::complex<double> (4,-2) );
	ret.SetAt(4,1,std::complex<double> (9,1.1) );
	return ret;
}
SparseMatrix <std::string> InitString()
{
	SparseMatrix <std::string> ret (5,4);
	ret.SetAt(1,1,"foo");
	ret.SetAt(2,2,"bar");
	ret.SetAt(3,1,"I love Gates");
	ret.SetAt(5,2,"hello");
	ret.SetAt(3,4,"01011001");
	ret.SetAt(4,1,"SOS");
	return ret;
}
void TestConstruct()
{
	std::cout<<"Here goes a matrix of integers:\n";
	SparseMatrix <int> a = InitInt();
	DisplayMatrix( a );
	std::cout<<"Here goes a matrix of chars:\n";
	DisplayMatrix( InitChar() );
	std::cout<<"Here goes a matrix of doubles:\n";
	DisplayMatrix( InitDouble() );
	std::cout<<"Here goes a matrix of complex:\n";
	DisplayMatrix( InitComplex() );
	std::cout<<"Here goes a matrix of strings:\n";
	DisplayMatrix( InitString() );
}
void TestCopyConstruct()
{
	SparseMatrix <int> a = InitInt();
	SparseMatrix <int> b = a;
	DisplayMatrix( b );
	SparseMatrix <std::string> c = InitString();
	SparseMatrix <std::string> d = c;
	DisplayMatrix( d );
	SparseMatrix <std::complex<double> > e = InitComplex();
	SparseMatrix <std::complex<double> > f = e;
	DisplayMatrix( f );
}

void TestHeightWidth()
{
	SparseMatrix <int> a = InitInt();
	DisplayMatrix( a );
	std::cout<<"The height of the matrix is: "<<a.GetHeight()<<std::endl;
	std::cout<<"The width of the matrix is: "<<a.GetWidth()<<std::endl;
}
void TestSetSize()
{
	SparseMatrix <double> a = InitDouble();
	std::cout<<"Initial matrix:\n";
	DisplayMatrix( a );
	std::cout<<"Enlarge it:\n";
	a.SetSize(6,6);
	DisplayMatrix( a );
	std::cout<<"Make it smaller:\n";
	a.SetSize(2,2);
	DisplayMatrix( a );
}
void TestGetAndSetEl()
{
	SparseMatrix <double> a = InitDouble();
	DisplayMatrix( a );
	std::cout<<"The element at (3,1) is: "<<a.At(3,1)<<std::endl;
	std::cout<<"Change it to 45:\n";
	a.SetAt(3,1,45);
	std::cout<<"The element at (3,1) is: "<<a.At(3,1)<<std::endl;

	SparseMatrix <std::string> b = InitString();
	DisplayMatrix( b );
	std::cout<<"The element at (3,1) is: "<<b.At(3,1)<<std::endl;
	std::cout<<"Change it to \"dream\" :\n";
	b.SetAt(3,1,"dream");
	std::cout<<"The element at (3,1) is: "<<b.At(3,1)<<std::endl;
	std::cout<<"Test the exception:\n";
	try {
	std::cout<<"The element at (10,10) is: "<<b.At(10,10)<<std::endl;
	}
	catch (OutOfRange& e)
	{
		std::cout<<e.what()<<std::endl;
	}
}

void TestSingular()
{
	const char* temp;
	SparseMatrix <double> a = InitDouble();
	DisplayMatrix( a );
	if (a.IsSingular()) 
	{
		temp="yes";
	}
	else
	{
		temp="no";
	}
	std::cout<<"Is it singular? "<<temp<<std::endl;
	a.SetAt(3,3,-0.45);
	DisplayMatrix( a );
	if (a.IsSingular()) 
	{
		temp="yes";
	}
	else
	{
		temp="no";
	}
	std::cout<<"Is it singular now? "<<temp<<std::endl;
}
void TestTranspose()
{
	SparseMatrix <int> a = InitInt ();
	DisplayMatrix( a );
	std::cout<<"After transpose:\n";
	SparseMatrix <int> b = a.Transpose();
	DisplayMatrix( b );
}
void TestAssignOperator ()
{
	SparseMatrix <char> a = InitChar();
	SparseMatrix <char> b = a;
	DisplayMatrix( b );
}
void TestOperatorAdd()
{
	SparseMatrix <std::string> a = InitString();
	DisplayMatrix( a );
	a=a+a;
	std::cout<<"After addition:\n";
	DisplayMatrix( a );
}
void TestOperatorSub()
{
	SparseMatrix <int> a = InitInt();
	SparseMatrix <int> b = a;
	std::cout<<"B\n";
	DisplayMatrix( b );
	a.SetAt(2,2,10);
	std::cout<<"minus A\n";
	DisplayMatrix( a );
	std::cout<<"equals\n";
	b=b-a;
	DisplayMatrix( b );
	std::cout<<"Test the exception:\n";
	try
	{
		b.SetSize(6,4);
		b=b-a;
	}
	catch (NotCompatible& e)
	{
		std::cout<<e.what()<<std::endl;
	}
}
void TestMulMatrix()
{
	SparseMatrix <int> a = InitInt();
	SparseMatrix <int> b = a.Transpose();
	std::cout<<"A\n";
	DisplayMatrix( a );
	std::cout<<"*B\n";
	DisplayMatrix( b );
	std::cout<<"equals\n";
	DisplayMatrix( a*b );
}
void TestAddAssign()
{
	SparseMatrix <std::complex<double> > a = InitComplex ();
	a+=a;
	DisplayMatrix( a );
}
void TestSubAssign()
{
	SparseMatrix <std::complex<double> > a = InitComplex ();
	SparseMatrix <std::complex<double> > b = a;
	b.SetAt(3,3,std::complex<double> (0,12) );
	a-=b;
	DisplayMatrix( a );
}
void TestMulNum()
{
	SparseMatrix <std::complex<double> > a = InitComplex ();
	a=a*3;
	DisplayMatrix( a );
}
void TestMulNumAssign()
{
	SparseMatrix <double> a = InitDouble ();
	a=a*3;
	DisplayMatrix( a );
}
void TestEqual()
{
	const char* temp;
	SparseMatrix <int> a = InitInt();
	SparseMatrix <int> b=a;
	if (a==b) 
	{
		temp="equal";
	}
	else
	{
		temp="not equal";
	}
	std::cout<<"Matrices are "<<temp<<std::endl;
	b.SetAt(1,1,78);
	if (a==b) 
	{
		temp="equal";
	}
	else
	{
		temp="not equal";
	}
	b.SetAt(1,1,78);
	std::cout<<"Matrices are "<<temp<<std::endl;
}
void TestNotEqual()
{
	const char* temp;
	SparseMatrix <int> a = InitInt();
	SparseMatrix <int> b=a;
	if (a!=b) 
	{
		temp="not equal";
	}
	else
	{
		temp="equal";
	}
	std::cout<<"Matrices are "<<temp<<std::endl;
	b.SetAt(1,1,78);
	if (a!=b) 
	{
		temp="not equal";
	}
	else
	{
		temp="equal";
	}
	b.SetAt(1,1,78);
	std::cout<<"Matrices are "<<temp<<std::endl;
}
